<?php
	$hostname="localhost";
	$username="root";
	$password="";
	$dbName="portal_college";

	$connectivity=mysqli_connect($hostname,$username,$password,$dbName);
?>