# Enrollment System
## School/College enrollment system
This is simple web application based on Php with MySql database.

## How to use
- Clone or download the project
- Copy all files and directory in htdocs directory inside xampp or lampp (for example: C:\xampp\htdocs\collegeportal)
- import database [ portl_college.sql ] in phpmyadmin
- Open any browser and entered localhost and browse file location. (for example: localhost/collegeportal)
- *Enjoy System* 
